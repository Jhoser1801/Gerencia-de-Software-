// ---------- Lógica pura (sin DOM) ----------
function productosValidos(lista) {
  // HU-02: un producto sin precio numérico no se puede seleccionar.
  return lista.filter(p => typeof p.precio === "number" && p.precio > 0);
}
function precioUnitario(producto, leche) {
  // BUG-01: siempre se calcula desde el precio base, nunca sobre el total anterior.
  return producto.precio + (LECHES[leche] || 0);
}
function totalCarrito(items) { return items.reduce((s, i) => s + i.precio, 0); }
const dinero = n => "$" + n.toLocaleString("es-CO");

// SCRUM-14: imagen según tamaño. La ruta sale de datos.js (producto.imagenes); sin tamaño se usa el neutro (Mediano).
const TAMANO_NEUTRO = "Mediano";
function claseTamano(t) { return "img-" + t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase(); }
function fotoMenu(producto) {
  // Foto del producto en la tarjeta del menú (tamaño neutro); si no hay ruta, se usa el icono.
  const ruta = (producto.imagenes || {})[TAMANO_NEUTRO];
  return ruta ? `<img class="foto" src="${ruta}" alt="${producto.nombre}">` : producto.icono;
}
function datosImagen(producto, tamano) {
  const t = tamano || TAMANO_NEUTRO;
  return { ruta: (producto.imagenes || {})[t] || "", clase: claseTamano(t), alt: `${producto.nombre}, tamaño ${t}` };
}
function htmlDeImagen(img) { return `<img class="${img.clase}" src="${img.ruta}" alt="${img.alt}">`; }
function htmlImagen(producto, tamano) { return htmlDeImagen(datosImagen(producto, tamano)); }

// ---------- Estado ----------
const estado = { producto: null, tamano: null, leche: "Entera" };
const carrito = [];
// Imagen de la ventana de personalización: se reasigna en elegirProducto() (+ Agregar) y en elegirTamano().
let imagenActual = null;
const $ = id => document.getElementById(id);

// ---------- Acciones ----------
function elegirProducto(id) {
  // HU-01/02/03: al elegir otra bebida se reinicia la configuración anterior.
  estado.producto = productosValidos(PRODUCTOS).find(p => p.id === id) || null;
  estado.tamano = null;
  estado.leche = "Entera";
  // Al presionar "+ Agregar": la imagen de la ventana se reasigna con el producto elegido (tamaño neutro).
  imagenActual = estado.producto ? datosImagen(estado.producto, null) : null;
  $("aviso-modal").textContent = "";
  if (estado.producto && $("modal").showModal) $("modal").showModal();
  pintar();
}
function elegirTamano(t) {
  estado.tamano = t;
  // Al elegir tamaño: la imagen se reasigna según ese tamaño (mismo producto).
  if (estado.producto) imagenActual = datosImagen(estado.producto, t);
  $("aviso-modal").textContent = "";
  pintar();
}
function elegirLeche(l) { estado.leche = l; pintar(); }
function agregarAlCarrito() {
  if (!estado.producto) return;
  if (!estado.tamano) { $("aviso-modal").textContent = "Faltan opciones por seleccionar: elige un tamaño."; return; }
  carrito.push({
    idProducto: estado.producto.id,
    nombre: estado.producto.nombre,
    tamano: estado.tamano,
    detalle: estado.tamano + " · Leche " + estado.leche,
    precio: precioUnitario(estado.producto, estado.leche)
  });
  cerrarModal();
}
function quitarDelCarrito(indice) {
  // SCRUM-14: elimina solo el ítem indicado; pintar() recalcula contadores, Subtotal y Total desde el carrito.
  if (!Number.isInteger(indice) || indice < 0 || indice >= carrito.length) return;
  carrito.splice(indice, 1);
  pintar();
}
function cerrarModal() {
  estado.producto = null; estado.tamano = null; estado.leche = "Entera"; imagenActual = null;
  if ($("modal").close && $("modal").open) $("modal").close();
  pintar();
}

// ---------- Pintado ----------
function pintar() {
  const lista = productosValidos(PRODUCTOS);
  $("menu").innerHTML = lista.length
    ? lista.map(p => `<article class="card"><div class="tile">${fotoMenu(p)}<span class="badge">Disponible</span></div>
        <h3>${p.nombre}</h3><p class="desc">${p.desc}</p><p class="precio">${dinero(p.precio)}</p>
        <button class="btn" onclick="elegirProducto(${p.id})">+ Agregar</button></article>`).join("")
    : "<p>No hay productos disponibles por el momento.</p>";

  const p = estado.producto;
  const aviso = $("aviso-modal") ? $("aviso-modal").textContent : "";
  $("detalle").innerHTML = !p ? '<p id="aviso-modal"></p>' : `<h2 id="m-tit">${p.nombre}</h2>
    <div class="vista"><div class="marco marco-modal">${htmlDeImagen(imagenActual)}</div>
    <p class="vista-tam">${estado.tamano ? "Tamaño: " + estado.tamano : "Elige un tamaño"}</p></div>
    <p class="precio" id="precio">${dinero(precioUnitario(p, estado.leche))}</p>
    <p>Tamaño</p>${TAMANOS.map(t => `<button class="op${estado.tamano === t ? " sel" : ""}" onclick="elegirTamano('${t}')">${t}</button>`).join("")}
    <p>Leche</p>${Object.keys(LECHES).map(l => `<button class="op${estado.leche === l ? " sel" : ""}" onclick="elegirLeche('${l}')">${l}${LECHES[l] ? " (+" + dinero(LECHES[l]) + ")" : ""}</button>`).join("")}
    <p id="aviso-modal" role="alert" style="color:#c0392b;min-height:1.3rem">${aviso}</p>
    <button class="btn" onclick="agregarAlCarrito()">Agregar al carrito</button>
    <button class="cerrar" onclick="cerrarModal()">Cancelar</button>`;

  $("lista").innerHTML = carrito.length
    ? carrito.map((i, n) => `<li><div class="marco marco-carro">${htmlImagen(PRODUCTOS.find(p => p.id === i.idProducto), i.tamano)}</div>
        <span class="info"><strong>${i.nombre}</strong><br><small>${i.detalle}</small><br>${dinero(i.precio)}</span>
        <button class="quitar" onclick="quitarDelCarrito(${n})" aria-label="Quitar ${i.nombre} del pedido">Quitar</button></li>`).join("")
    : '<li class="vacio">🧺<br>Aún no has agregado nada a tu pedido.</li>';
  $("contador").textContent = carrito.length;
  $("items").textContent = carrito.length + (carrito.length === 1 ? " item" : " items");
  $("subtotal").textContent = $("total").textContent = dinero(totalCarrito(carrito));
}
$("modal").addEventListener("close", () => { estado.producto = null; estado.tamano = null; imagenActual = null; pintar(); });
pintar();
