# Lattely – Sprint 1 (Base funcional + SCRUM-14)

Equipo: Jhoser, Stevan, Joseph, Camilo. Versión presentada: `<commit o ZIP>`.

## Versiones e instalación
Sin dependencias, sin Node, sin build. Navegador moderno (Chrome, Edge o Firefox). Instalación: descomprimir la carpeta.

## Ejecución
Abrir `index.html` con doble clic. No hay que modificar código.

## Datos de prueba (`datos.js`)
Latte $5.200 · Cappuccino $4.500 · Americano Frío $3.800 · Té Chai $4.800.
Tamaños: Pequeño, Mediano, Grande, sin recargo (Jira no define recargo por tamaño).
Leche: Entera $0, Deslactosada $0, Almendras +$2.000.

## Archivos
`index.html` · `estilos.css` · `datos.js` (productos, tamaños, recargos, rutas de imagen) · `app.js` (estado y lógica) · `img/` (una foto por producto, recortada en cuadrado a 600×600: `latte.jpg`, `cappuccino.jpg`, `americano-frio.jpg`, `te-chai.jpg`).

## Imágenes por tamaño (SCRUM-14)
Las imágenes se manejan con variables `let`: `PRODUCTOS` (con el objeto `imagenes` de cada producto) en `datos.js` e `imagenActual` (`{ruta, clase, alt}`) en `app.js`, que se reasigna en `elegirProducto()` (al presionar "+ Agregar") y en `elegirTamano()`.
La foto de cada bebida también aparece en la tarjeta del menú (`fotoMenu()` en `app.js`, usa la imagen del tamaño Mediano).
Cada producto define en `datos.js` su ruta por tamaño (`imagenes: { "Pequeño", "Mediano", "Grande" }`). Mientras no haya fotos reales, los tres tamaños usan el mismo archivo y `estilos.css` cambia su tamaño dentro de un recuadro fijo (proporción 70:100:130, siempre centrada y sin salirse del marco). Sin tamaño elegido se muestra el Mediano. El tamaño no cambia el precio. Para usar fotos reales: guardarlas en `img/` (p. ej. `latte-pequeno.png`), y cambiar la ruta en `datos.js`; el tamaño dentro del recuadro sigue funcionando igual.

## Relación de historias
| HU | Jira | Responsable | Código | Evidencia |
|---|---|---|---|---|
| HU-01 Menú | SCRUM-7 | Jhoser | `pintar()`, `elegirProducto()` | demo del catálogo y `datos.js` |
| HU-02 Precio | SCRUM-8 | Stevan | `productosValidos()`, `precioUnitario()` | captura vs `datos.js` |
| HU-03 Tamaño | SCRUM-9 | Joseph | `elegirTamano()`, `estado.tamano` | demo 3 tamaños |
| HU-04 Leche | SCRUM-10 | Camilo | `LECHES`, `elegirLeche()` | demo + BUG-01 |
| HU-05 Carrito | SCRUM-11 | Jhoser | `agregarAlCarrito()` | contador y rechazo sin tamaño |
| HU-06 Total | SCRUM-12 | Camilo | `totalCarrito()` | Subtotal/Total del panel |
| Quitar del carrito + imagen por tamaño | SCRUM-14 | Por asignar | `quitarDelCarrito()`, `htmlImagen()`, `imagenes` en `datos.js` | demo de Quitar y de imagen en ventana y carrito |

Implementó / revisó / probó: completar por historia con enlace al commit.
No implementadas ni declaradas: SCRUM-13. Lo parcial no suma SP.

## Pruebas
**V** = verificado con script de lógica en Node (P12–P14 con DOM simulado). **Pendiente** = ejecutar en navegador y anotar el resultado real.

| ID | Historia | Pasos | Esperado | Obtenido |
|---|---|---|---|---|
| P1 | HU-01 éxito | Elegir Latte y luego Cappuccino | La ventana muestra el producto elegido | Pendiente |
| P2 | HU-01 límite | `PRODUCTOS = []` | "No hay productos disponibles por el momento." | Pendiente |
| P3 | HU-02 éxito | Ver precios de Latte y Té Chai | $5.200 y $4.800, igual a `datos.js` | Pendiente |
| P4 | HU-02 inválido | Producto sin `precio` | No aparece en el menú | V |
| P5 | HU-03 éxito | Elegir Pequeño, Mediano, Grande | La opción elegida queda resaltada | Pendiente |
| P6 | HU-03 inválido | Agregar sin tamaño | Aviso de tamaño faltante, carrito en 0 | V |
| P7 | Integración | Latte + Grande, luego Cappuccino | Cappuccino sin tamaño elegido | V |
| P8 | HU-04 éxito | Latte, Almendras | $7.200 | V |
| P9 | HU-04 / BUG-01 | Alternar Almendras↔Entera varias veces | Siempre base +$2.000, nunca +$4.000 | V |
| P10 | HU-05 éxito | Latte Mediano, Agregar | Contador 0→1 | V |
| P11 | HU-06 éxito | Latte Almendras + Americano Frío Pequeño | Total $11.000 | V |
| P12 | SCRUM-14 Quitar éxito | Latte Mediano Almendras + Americano Frío Pequeño; presionar Quitar en el Latte | Total baja de $11.000 a $3.800, contador 2→1, solo queda el Americano | V |
| P13 | SCRUM-14 Quitar límite | Después de P12, presionar Quitar en el último ítem | "Aún no has agregado nada a tu pedido.", total $0, contador 0 | V |
| P14 | SCRUM-14 Imagen por tamaño | Abrir "+ Agregar" en Latte; sin tamaño y luego Pequeño, Mediano, Grande; agregar y mirar el carrito | Neutro Mediano al inicio; la imagen cambia de tamaño (70:100:130) centrada y sin salirse del recuadro y el precio no cambia; el carrito muestra la imagen con el tamaño elegido | V lógica/DOM; apariencia visual: Pendiente en navegador |

## Bugs observados
Ninguno en las pruebas anteriores. BUG-01 (SCRUM-22) se previno calculando siempre desde el precio base; P9 lo confirma. Vincular P9 con SCRUM-10.

## Créditos de imágenes
Fotos tomadas de Wikipedia / Wikimedia Commons (licencias Creative Commons; recortadas y reducidas para la página):
- Latte: https://en.wikipedia.org/wiki/Latte
- Cappuccino: https://es.wikipedia.org/wiki/Capuchino_(caf%C3%A9)
- Americano: https://en.wikipedia.org/wiki/File:Espresso_Americano.jpeg
- Té Chai: https://commons.wikimedia.org/wiki/File:A_cup_of_chai.JPG
Pendiente: anotar autor y licencia exacta de cada archivo (se ven en la página «File:» de cada imagen).
