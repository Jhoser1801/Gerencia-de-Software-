// Datos del proyecto Lattely. El menú, el precio, los recargos y las rutas de imágenes salen de aquí.
// Imágenes (SCRUM-14): una ruta por producto y tamaño. Hoy los tres tamaños apuntan a la misma foto (img/*.jpg)
// y estilos.css cambia el tamaño dentro del recuadro (proporción 70:100:130). Si tienes fotos reales por tamaño,
// súbelas a img/ (p. ej. img/latte-pequeno.png) y cambia aquí la ruta; el tamaño dentro del recuadro se mantiene.
let PRODUCTOS = [
  { id: 1, nombre: "Latte", precio: 5200, desc: "Espresso con leche vaporizada.", icono: "☕",
    imagenes: { "Pequeño": "img/latte.jpg", "Mediano": "img/latte.jpg", "Grande": "img/latte.jpg" } },
  { id: 2, nombre: "Cappuccino", precio: 4500, desc: "Espresso, leche y espuma cremosa.", icono: "☕",
    imagenes: { "Pequeño": "img/cappuccino.jpg", "Mediano": "img/cappuccino.jpg", "Grande": "img/cappuccino.jpg" } },
  { id: 3, nombre: "Americano Frío", precio: 3800, desc: "Café con hielo, ligero y fresco.", icono: "🧊",
    imagenes: { "Pequeño": "img/americano-frio.jpg", "Mediano": "img/americano-frio.jpg", "Grande": "img/americano-frio.jpg" } },
  { id: 4, nombre: "Té Chai", precio: 4800, desc: "Té especiado con leche.", icono: "🍵",
    imagenes: { "Pequeño": "img/te-chai.jpg", "Mediano": "img/te-chai.jpg", "Grande": "img/te-chai.jpg" } }
];

// HU-03: Jira no define recargo por tamaño, por eso no hay precios por tamaño.
const TAMANOS = ["Pequeño", "Mediano", "Grande"];
// HU-04: recargo por leche (almendras +$2.000 según BUG-01).
const LECHES = { "Entera": 0, "Deslactosada": 0, "Almendras": 2000 };
